package br.ufv.dpi.metrics;

public class Main {

	public static void main(String args []) {
		ComputeMetrics m = new ComputeMetrics();
		m.compute();
		//m.printKBestVisual(500);
		//m.printMetrics();
		m.printLabels();
	}
	
}
